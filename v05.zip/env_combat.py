import numpy as np
import time
import pickle
import os

class c_action_space:
	def __init__(self,n):
		self.n=n

class env_combat:
	def __init__(self,params,show=False):
		# NEW CODE
		self.team1_img = None
		self.team2_img = None


		self.starting_points = np.zeros((9,2))
		for i in range(-1,2):
			for j in range(-1,2):
				self.starting_points[(i+1)*3+(j+1),0] = i
				self.starting_points[(i+1)*3+(j+1),1] = j	
		self.p = params
		self.debug_mode = self.p['env_debug']
		self.action_space = c_action_space(self.p['num_actions'])
		self.perception_dim=((2*self.p['sight']+1)**2)*6
		self.showornot = show
		if self.showornot : 
			self.cv2 = __import__('cv2')
			e = self.p['show_expand']
			self.team1_img = self.cv2.resize(self.cv2.imread('pikachu.jpg'), (e, e))
			self.team2_img = self.cv2.resize(self.cv2.imread('charmander.jpg'), (e, e))
			self.cv2.startWindowThread()
			self.cv2.namedWindow('screen')
			if self.debug_mode :self.cv2.namedWindow('screen_mirror')
			if self.p['agent1'] == 'ours' : 
				self.cv2.namedWindow('attention1')
			if self.p['agent2'] == 'ours' : 
				self.cv2.namedWindow('attention2')
		self.reset()


	def reset(self):
		self.action_log = np.zeros(2*self.p['num_agents']) #used for visualization
		self.deploy()
		self.term = 0
		return self.percieve()
		

	def deploy(self):
		if self.debug_mode:
			print('###  deploy ###')
		self.agent1_team = 1
		self.agent2_team = 2
		self.offset1 = self.p['num_agents']*(self.agent1_team-1)
		self.offset2 = self.p['num_agents']*(self.agent2_team-1)
		self.timestep = 0
		self.info_tanks = np.zeros((2*self.p['num_agents'],6)) #x,y,idx,team,hp,cool
		sa = int(float(self.p['field_size'])/5.0)
		sb = int(4.0*float(self.p['field_size'])/5.0)
		self.start_agents = np.array([sa,sa])
		self.start_bots = np.array([sb,sb])
		self.bot_vision = np.zeros(self.p['num_agents'])
		self.action_log = np.zeros(2*self.p['num_agents'])
		self.info_tanks[:,4] = self.p['hp']
		self.info_tanks[0:5,3] = 1.0
		self.info_tanks[5:10,3] = 2.0

		pos_permu = np.random.permutation(9)
		for i in range(0,self.p['num_agents']) : 
			self.info_tanks[i,2] = i
			self.info_tanks[i,0:2] = self.starting_points[pos_permu[i]] + self.start_agents

		pos_permu = np.random.permutation(9)
		for i in range(0,self.p['num_agents']) : 
			self.info_tanks[i+self.p['num_agents'],2] = i+self.p['num_agents']
			self.info_tanks[i+self.p['num_agents'],0:2] = self.starting_points[pos_permu[i]] + self.start_bots

		if self.debug_mode:
			print(self.info_tanks)
			print(self.agent1_team, self.offset1)
			print(self.agent2_team, self.offset2)


		return None


	


	def show(self,infos,actionlog,attention1=None,attention2=None):
		'''
		show game screen

		use following informations

		self.p : contains parameters (see parameters.py)
			self.p['num_agents'] : number of agents for 'each team'
			self.p['field_size'] : size of battlefield (each dimension)

		infos : 2d np array with shape (2*num_agents,6). second dimension represents (x_position,y_position,index_of_agent,team_of_agent,hp_of_agent,cooldown_of_agent)
			x_position, y_position : integer between 0~field_size
			index_of_agents : integer between 0~2*num_agents, it is same to the index of row.
			team_of_agents : integer. 0 or 1 (0:our agent, 1:bot). agent 0~num_agents are team0 and agent num_agents~2*num_agents are team1
			hp_of_agent : integer between 0~max_hp. dead when 0
			cooldown_of_agent : integer. 0 or 1. cannot attack when cooldown=1

		actionlog will be 1d np array that represents action of each agent.
			[action index of agent 0, ... , action index of agent 10]
			for agent 0~4, index 5~9 means attacking agent 5~9
			for agent 5~9, index 5~9 means attacking agent 0~4

		
		'''
		

		#temporary code for debugging
		img = np.zeros((self.p['field_size']*self.p['show_expand'],self.p['field_size']*self.p['show_expand'],3)).astype('uint8')
		e = self.p['show_expand']
		# NEW CODE draw characters
		for i in range(2*self.p['num_agents']):
			if infos[i,0] >= 0 and infos[i,1] >= 0:
				x = int(infos[i,0])
				y = int(infos[i,1])
				team = int(infos[i,3])
				idx = int(infos[i,2])
				hp = int(infos[i,4]) 
				cool = int(infos[i,5])
				if team == 1 : img[y*e:(y+1)*e,x*e:(x+1)*e,:]=self.team1_img #team1
				else : img[y*e:(y+1)*e,x*e:(x+1)*e,:]=self.team2_img  #team2



		# NEW CODE draw attack
		for i in range(2*self.p['num_agents']):
			if infos[i,0] >= 0 and infos[i,1] >= 0:
				x = int(infos[i,0])
				y = int(infos[i,1])
				team = int(infos[i,3])
				if team == 1:
					target_i = int(actionlog[i]) +1
				else:
					target_i = int(actionlog[i]) - self.p['num_agents'] + 1	
				
				x2 = int(infos[target_i, 0])
				y2 = int(infos[target_i, 1])
				team2 = int(infos[target_i, 3])
				if np.absolute(x - x2) > 1 or np.absolute(y - y2) > 1 or team == team2:
					continue
				#print (i, target_i)
				if team == 1: 
					c = (0, 255, 255) # team1: Yello
					self.cv2.line(img,((x+1)*e - e/2 - 3, (y+1)*e - e/2),((x2+1)*e - e/2 - 3,(y2+1)*e - e/2),c,3)
				else: 
					c = (0, 0, 255) # team2: Red
					self.cv2.line(img,((x+1)*e - e/2 + 3,(y+1)*e - e/2),((x2+1)*e - e/2 + 3,(y2+1)*e - e/2),c,3)
					
		#time.sleep(0.1)
		
		# draw indices
		for i in range(2*self.p['num_agents']):
			if infos[i,0] >= 0 and infos[i,1] >= 0:
				x = int(infos[i,0])
				y = int(infos[i,1])
				team = int(infos[i,3])
				idx = int(infos[i,2])
				hp = int(infos[i,4]) 
				cool = int(infos[i,5])
				self.cv2.putText(img,str(idx),(e*x,e*(y)),self.cv2.FONT_HERSHEY_SIMPLEX,0.5,color=(255,255,255),thickness=2)
		#draw teams
		if self.agent1_team == 1 :
			self.cv2.putText(img,'Pikachu(team1) : ' + self.p['agent1'],(20,25),self.cv2.FONT_HERSHEY_SIMPLEX,0.6,color=(255,255,255),thickness=2)
			self.cv2.putText(img,'Charmander(team2) : ' + self.p['agent2'],(20,50),self.cv2.FONT_HERSHEY_SIMPLEX,0.6,color=(255,255,255),thickness=2)
		else:
			self.cv2.putText(img,'Pikachu(team1) : ' + self.p['agent2'],(20,25),self.cv2.FONT_HERSHEY_SIMPLEX,0.6,color=(255,255,255),thickness=2)
			self.cv2.putText(img,'Charmander(team2) : ' + self.p['agent1'],(20,50),self.cv2.FONT_HERSHEY_SIMPLEX,0.6,color=(255,255,255),thickness=2)

		#draw step
		self.cv2.putText(img,'timestep : ' + str(self.timestep),(self.p['field_size']*self.p['show_expand']-210,25),self.cv2.FONT_HERSHEY_SIMPLEX,0.6,color=(255,255,255),thickness=2)
		#show			
		self.cv2.imshow('screen',img)
		if self.debug_mode : self.cv2.imshow('screen_mirror',self.cv2.flip(img,-1))

		#display attentions
		if attention1 is not None :
			att_img = attention1.reshape((self.p['num_agents'],self.p['num_agents']))
			att_img = att_img*255.0
			ee = 30
			att_img_expand = np.zeros((self.p['num_agents']*ee,self.p['num_agents']*ee))
			for i in range(self.p['num_agents']):
				for j in range(self.p['num_agents']):	
					att_img_expand[i*ee:(i+1)*ee,j*ee:(j+1)*ee] = att_img[i,j]		

			self.cv2.imshow('attention1',att_img_expand.astype('uint8'))

		if attention2 is not None :
			att_img = attention2.reshape((self.p['num_agents'],self.p['num_agents']))
			att_img = att_img*255.0
			ee = 30
			att_img_expand = np.zeros((self.p['num_agents']*ee,self.p['num_agents']*ee))
			for i in range(self.p['num_agents']):
				for j in range(self.p['num_agents']):	
					att_img_expand[i*ee:(i+1)*ee,j*ee:(j+1)*ee] = att_img[i,j]		

			self.cv2.imshow('attention2',att_img_expand.astype('uint8'))

		time.sleep(self.p['vis_delay'])
		


		#print infos
		#print actionlog
		#print self.bot_vision
		#print self.bot_targets
		#aaaa = raw_input('aa')


		return None
		

	def get_mask(self):
		output = (self.info_tanks[:,4]>0).astype('float').reshape((-1,1))
		if self.debug_mode :
			print('### get_mask ###')
			print(output)
		return output

	def step(self,action,att1,att2): #[idx,action], 0:up, 1:down, 2:left, 3:right, 4~8 : attack  #return the next state and reward and term

		info_prev = self.info_tanks.copy()
		if self.p['agent1'] == 'bot' : action[self.offset1:self.offset1+self.p['num_agents']] = self.get_bot_actions(self.agent1_team)
		if self.p['agent2'] == 'bot' : action[self.offset2:self.offset2+self.p['num_agents']] = self.get_bot_actions(self.agent2_team)
		self.action_log = action

		self.damages = np.zeros(2*self.p['num_agents'])

		#Process moves before processing attacks

		for idx in range( self.p['num_agents'] ):
			if self.info_tanks[idx,4] <= 0 or action[idx] == self.p['num_agents']+4: continue	#dead or do_nothing	
			if action[idx] == 0 : self.move(idx,0)
			elif action[idx] == 1 : self.move(idx,1)
			elif action[idx] == 2 : self.move(idx,2)
			elif action[idx] == 3 : self.move(idx,3)


		#team2 : mirror movements for team2
		for idx in range( self.p['num_agents'] , 2*self.p['num_agents']  ):
			if self.info_tanks[idx,4] <= 0 or action[idx] == self.p['num_agents']+4: continue	#dead or do_nothing	
			if action[idx] == 0 : self.move(idx,1)
			elif action[idx] == 1 : self.move(idx,0)
			elif action[idx] == 2 : self.move(idx,3)
			elif action[idx] == 3 : self.move(idx,2)


		for idx in range(2*self.p['num_agents']):
			if idx >= self.p['num_agents'] : team_off = 0
			else : team_off = self.p['num_agents']
			if action[idx] >= 4 and action[idx] < self.p['num_agents']+4 :
				self.attack(idx,action[idx]-4+team_off)
		#print self.info_tanks[:,5]
		self.info_tanks[:,5] = np.maximum(0,self.info_tanks[:,5]-1)
		#print self.info_tanks[:,5]
		self.timestep += 1
		result = self.check()

		if self.showornot : self.show(info_prev,self.action_log,att1,att2)

		if self.debug_mode :
			print('### step ###')
			print('-arguments-')
			print(action)
			print(att1)
			print(att2)
			print('-----------')
			print(self.damages)
			print(self.info_tanks)
			aa = raw_input('dd')
	

		
		return self.percieve(), result, self.term,self.get_mask()

	def move(self,idx,direction):
		
		if self.info_tanks[idx,4] <= 0 : return None

		x = self.info_tanks[idx,0]
		y = self.info_tanks[idx,1]

		if direction == 0 : tx=x ; ty=max(0,y-1)  #up
		elif direction == 1 : tx=x ; ty=min(self.p['field_size']-1,y+1) #down
		elif direction == 2 : tx=max(0,x-1) ; ty=y #left
		elif direction == 3 : tx=min(self.p['field_size']-1,x+1) ; ty=y #right

		stuck = 0

		for i in range(self.p['num_agents']*2):
			if i == idx : continue
			if tx==self.info_tanks[i,0] and ty==self.info_tanks[i,1] : stuck = 1 ; break
		if stuck == 0 : self.info_tanks[idx,0] = tx ; self.info_tanks[idx,1]=ty
		if self.debug_mode : 
			words = ['up','down','left','right']
			if stuck == 0 : print('### move : ', str(idx),' move from (',str(x),','+str(y),' to (',str(tx),',',str(ty),') (',str(direction),words[direction],') -> success')
			else : print('### move : ', str(idx),' move from (',str(x),','+str(y),' to (',str(tx),',',str(ty),') (',str(direction),words[direction],') -> fail')
		return None


	def attack(self,idx,idx2): 
		idx = int(idx);idx2=int(idx2);valid=1
		if self.debug_mode : 
			print('### attack : ' + str(idx) + ' attacked ' + str(idx2))
		if self.info_tanks[idx,5] > 0 : 
			valid = 0 #cooldown
			if self.debug_mode : print( ' -> fail(cooldown)')
		if self.info_tanks[idx2,4] <= 0 : 
			valid = 0 #target is dead already
			#self.info_tanks[idx,5] = self.p['cooldown']+1
			if self.debug_mode : print( ' -> fail(target dead)')
		dx = abs(self.info_tanks[idx,0] - self.info_tanks[idx2,0])
		dy = abs(self.info_tanks[idx,1] - self.info_tanks[idx2,1])
		if dx > self.p['attack_range'] or dy > self.p['attack_range']: 
			valid = 0
			#self.info_tanks[idx,5] = self.p['cooldown']+1
			if self.debug_mode : print( ' -> fail(too far : ' + str(dx) +',' + str(dy) +')')
		if valid == 1 : 
			self.damages[idx2] += 1.0
			self.info_tanks[idx,5] = self.p['cooldown']+1 # set cooldown
			if self.debug_mode : print( ' -> success')
			 



		



	def check(self):
		#process damages
		shot_rewards = np.minimum(self.info_tanks[:,4],self.damages)
		self.info_tanks[:,4] = np.maximum(0.0,self.info_tanks[:,4]-self.damages)
		deads = ( self.info_tanks[:,4] <= 0 )
		self.info_tanks[deads,0:2] = -1

		team1_reward = self.p['reward_shot']*np.sum(shot_rewards[self.p['num_agents']:])
		team2_reward = self.p['reward_shot']*np.sum(shot_rewards[:self.p['num_agents']])
			
		eli_team1 = 0
		eli_team2 = 0
		
		if (self.info_tanks[0:self.p['num_agents'],4] <= 0).all() : eli_team1 = 1
		if (self.info_tanks[self.p['num_agents']:2*self.p['num_agents'],4] <= 0).all() : eli_team2 = 1
		win_team1 = 0
		win_team2 = 0

		if (eli_team1 == 1 and eli_team2 == 1) or self.timestep >= self.p['timeout'] : 
			#print 'draw'
			hp_t1 = np.sum(self.info_tanks[:self.p['num_agents'],4])
			hp_t2 = np.sum(self.info_tanks[self.p['num_agents']:,4])
			team1_reward += self.p['reward_lose'] + self.p['hpmul']*hp_t2
			team2_reward += self.p['reward_lose'] + self.p['hpmul']*hp_t1
			if hp_t1 > hp_t2 : win_team1 = 1
			elif hp_t1 < hp_t2 : win_team2 = 1
			self.term = 1
		elif eli_team1 == 1  : 
			#print 'team2 wins'
			team1_reward += self.p['reward_lose'] + self.p['hpmul']*np.sum(self.info_tanks[self.p['num_agents']:,4])
			team2_reward += self.p['reward_win']
			self.term = 1; win_team2 = 1
		elif eli_team2 == 1 : 
			#print 'team1 wins'
			team1_reward += self.p['reward_win']
			team2_reward += self.p['reward_lose'] + self.p['hpmul']*np.sum(self.info_tanks[:self.p['num_agents'],4])
			self.term = 1; win_team1 = 1
		#print reward
		output = [   [team1_reward,team2_reward]   ,   [win_team1,win_team2]   ]
		if self.debug_mode :
			print( '### check ### ' )
			print( output) #note th
		return output


	def percieve(self): #return (2*num_agent,perception_dim)
		result = np.zeros((2*self.p['num_agents'],self.perception_dim))

		for i in range(2*self.p['num_agents']):
			if self.info_tanks[i,4] <= 0.0 : continue

			x = self.info_tanks[i,0]
			y = self.info_tanks[i,1]
			s = self.p['sight']

			temp = np.zeros(((2*s+1)**2,6))
			
			for j in range(-s,s+1):
				for k in range(-s,s+1):
					jj = j ; kk = k
					if i >= self.p['num_agents'] : jj = -jj ; kk = -kk
					if x+jj < 0 or x+jj >= self.p['field_size'] or y+kk < 0 or y+kk >= self.p['field_size'] : continue
					for l in range(2*self.p['num_agents']):
						if self.info_tanks[l,0] == x+jj and self.info_tanks[l,1] == y+kk and self.info_tanks[l,4] > 0 : temp[(2*s+1)*(j+s)+(k+s),:]=self.info_tanks[l]
			
			if i >= self.p['num_agents'] : 
				temp[temp[:,3]>0,:2] = self.p['field_size']-temp[temp[:,3]>0,:2]-1
				temp[temp[:,3]>0,3] = 3.0-temp[temp[:,3]>0,3]	
				temp[temp[:,3]==1,2] = -self.p['num_agents'] + temp[temp[:,3]==1,2]
				temp[temp[:,3]==2,2] = self.p['num_agents']+ temp[temp[:,3]==2,2]														
			if self.debug_mode : 
				print( '### percieve ###')
				print( 'agent ',i, ' (team ',self.info_tanks[i,3],')')
				print( temp)
			#normalize
			temp[:,:2] = temp[:,:2]/float(self.p['field_size'])
			temp[:,2] = temp[:,2]/float(self.p['num_agents']*2)
			temp[:,3] = temp[:,3]/2.0
			temp[:,4] = temp[:,4]/float(self.p['hp'])
			result[i,:] = temp.reshape(-1)


					
		return result

	def bot_find_enemies(self,team):
		self.bot_vision = np.zeros(self.p['num_agents'])
		team_offset = (2-team) * self.p['num_agents']		
		for i in range(self.p['num_agents']):
			me=self.p['num_agents']-team_offset+i
			if self.info_tanks[me,4]<=0.0 : continue
			xa = self.info_tanks[me,0]
			ya = self.info_tanks[me,1]
			for j in range(self.p['num_agents']):
				you = team_offset+j
				if self.info_tanks[you,4]<=0.0 : continue
				xb = self.info_tanks[you,0]
				yb = self.info_tanks[you,1]
				if abs(xa-xb) <= self.p['sight'] and abs(ya-yb) <= self.p['sight']: self.bot_vision[j] = 1
		if self.debug_mode :
			print( '### bot_find_enemies ### ')
			print( team)
			print( self.bot_vision )
					

	def find_nearest_enemy(self,idx,team):
		#return nearest enemy (for bots)
		x = self.info_tanks[idx,0]
		y = self.info_tanks[idx,1]
		nearest_dist = 999999
		nearest_idx = -1
		team_offset = (2-team) * self.p['num_agents']		
		for i in range(self.p['num_agents']):
			if self.bot_vision[i] == 0 : continue
			xx = self.info_tanks[i+team_offset,0]
			yy = self.info_tanks[i+team_offset,1]
			if (x-xx)**2+(y-yy)**2 < nearest_dist : 
				nearest_dist = (x-xx)**2+(y-yy)**2
				nearest_idx = i
		if self.debug_mode :
			print( '### bot_find_nearst enemy : ' + str(idx) + '(team ' + str(team) + ') targets ' + str(nearest_idx) )

		return nearest_idx

	def get_bot_actions(self,team):
		#each bot attacks nearest visible enemy. random walk when no enemy spotted.
		actions = np.zeros(self.p['num_agents'])
		self.bot_find_enemies(team)
		self.bot_targets = np.ones((self.p['num_agents']))*-1
		team_offset = (2-team) * self.p['num_agents']
		for i in range(self.p['num_agents']):
			me = i+self.p['num_agents']-team_offset
			if self.info_tanks[me,4] <= 0 : continue
			target = self.find_nearest_enemy(me,team)

			if target == -1 : #no visible target - random walk
				direction = np.random.randint(0,4)
				actions[i] = direction
				continue			

			x = self.info_tanks[me,0]
			y = self.info_tanks[me,1]
			xx = self.info_tanks[target+team_offset,0]
			yy = self.info_tanks[target+team_offset,1]			

			if abs(x-xx) < 2 and abs(y-yy) < 2 : 
				actions[i] = target+4				
				
			else:
				if team == 1 :
					if x > xx : actions[i] = 2
					elif x < xx : actions[i] = 3
					elif y > yy : actions[i] = 0
					elif y < yy : actions[i] = 1
				elif team == 2 :
					if x > xx : actions[i] = 3
					elif x < xx : actions[i] = 2
					elif y > yy : actions[i] = 1
					elif y < yy : actions[i] = 0

		if self.debug_mode :
			print( '### get_bot_actions ### ')
			print( team)
			print( actions)

		return actions


