import time
import numpy as np

class asdf:
	def __init__(self,aa):
		img = np.ones((200,200,3))
		img = img*255.0
		self.img = img.astype('uint8')
		self.cv2 = None
		if aa : self.cv2 = __import__('cv2')

	def show(self):
		if self.cv2 is None: print 'no cv' ; return None
		else : print 'yes cv'
		self.cv2.imshow('aa',self.img)
		self.cv2.waitKey(1)
		time.sleep(3)


ff = asdf(False)
ff.show()

gg = asdf(True)
gg.show()

ff.show()





