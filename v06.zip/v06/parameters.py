'''
Hyperparameters for Asynchronous Methods for Deep Reinforcement Learning 
Jinyoung Choi
'''
def load_params():
	params = {
		#Meta
		'exp_name':'noname', #the tensorboard event files will be saved in the folder 'params[log_path]+params[log_name]'
		'log_path':'logs/',
		'ckpt_path':'ckpt/', #the checkpoint files will be saved in params['ckpt_path']
		'ckpt_agent1' : None, #checkpoint file name (including full path)
		'ckpt_agent2' : None, #checkpoint file name (including full path)
		'eval_mode':False, #no training. only evaluations.
		'eval_wait':0., #seconds. waiting time between frames in evaluation mode.
		'show_0th_thread':False, #show 0th thread's screen?
		'device':"/gpu:0", #gpu device index
		#environment
		'vis_delay' : 0.0, #visualization delay
		'num_agents' : 5, #num of agents for each team
		'hp' : 3, #health point of each agent
		'field_size' : 8, # field siz (per side)
		'sight' : 1, #sight range for each agent
		'attack_range' : 1, # attack range for each agent
		'timeout':80, #game ends after this time step
		'num_actions' : 7, #number of actions for each agent, 0:up, 1:down, 2:left, 3:right, 4~8 : attack
		'hpmul' : -0.2, #if game ends with timeout, agents recieve (sum of remaining enemy hp)*hpmul rewards.
		'show_expand' : 50, #pixel per cell
		'reward_win':0.0, #base reward for win
		'reward_lose':-0.5, #base reward for lose
		'reward_shot':0.0, #reward for each successful attack
		'reward_hit':0.0, #reward for each hit		
		'cooldown' : 1, #After attack, cannot attack again for this time step 
		'env_debug': False, #debug mode
		#Networks , no conv or LSTM
		'agent1' : 'ours', #agent type : ours, commnn, dense, nocomm, bot
		'agent2' : 'nocomm', #agent type : ours, commnn, dense, nocomm, bot
		'num_workers': 8, #number of threads
		'dim_fc_ours' : [256,256], #dimensions of fc layers. len(params['dim_fc']) is the number of fc layers. it does not include LSTM layer.
		'dim_comm_ours' : [64], #dimensions of receiver and transmitter features in our model
		'dim_fc_commnn' : [214,214], #dimensions of fc layers. len(params['dim_fc']) is the number of fc layers. it does not include LSTM layer.
		'dim_fc_dense' : [128,128], #dimensions of fc layers. len(params['dim_fc']) is the number of fc layers. it does not include LSTM layer.
		'dim_fc_nocomm' : [305,305], #dimensions of fc layers. len(params['dim_fc']) is the number of fc layers. it does not include LSTM layer.
		'entropy_reg_coeff':0.001, #entropy regularization coefficient in A3C		
		'activations':'elu', #see TF_utils_cjy.py for possible activations.
		#training
		'max_step' : 20,
		'queue_max' : 1000, #maximum minibatch size
		'queue_min' : 0, #minimum minibatch size
		'discount' : 1.0,
		'lr' : 1e-4, #calculated using loguniform.		
		'rms_decay':0.99, #not used
		'rms_momentum':0.0, #not used
		'rms_eps':0.1, #not used
		'max_T' : 25*(10**6), #The learning ends in this frame.
		'score_display_interval' : 100, #episodes. display 0th thread's mean score after every 'score_display_interval' episodes
		'save_interval' : 1000000, #frames. save the check point in every 'save_interval' frames
		'eval_interval' : 30*4*(10**6)-2,#frames. Pause the learning and do the evaluation in every 'eval_interval' frames
		'eval_duration' : 20,#episodes. number of evaluation episodes.
		'clip_grad' : True, #whether or not clip the gradient
		'grad_clip_norm' : 40., #norm bound for gradient
		'clip_reward' : False, #clip reward to [-1.~1.], KEEP IT FALSE
		'eps_max' : [1.0,1.0,1.0], #maximum epsilon in AnDQN
		'eps_min' : [0.1,0.01,0.5], #minimum epsilon in AnDQN
		'eps_frame' : [1000000,1000000,1000000], #epsilon will be annealed lineary and it will be 'eps_min' after this frame.
		'eps_prob' : [0.4,0.3,0.3], #every thread pick one of epsilon settings with this distribution
		'target_copy_interval' : 30000, #interval between target net copy in AnDQN
		}

	return params
