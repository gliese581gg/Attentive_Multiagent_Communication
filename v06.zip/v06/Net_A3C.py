'''
Networks for Asynchronous Methods for Deep Reinforcement Learning 
Jinyoung Choi
'''
import numpy as np
import tensorflow as tf
import TF_utils_cjy as tu
#from tensorflow.python.ops import rnn, rnn_cell
from tensorflow.contrib import rnn

def commnn_layer(layer_name,inputs,dim,activation,num_agents):
	inputs_reshape = tf.reshape(inputs,[   -1, num_agents, tf.shape(inputs)[-1]   ])
	inputs_sum = tf.reduce_sum(inputs_reshape,axis=1,keep_dims=True)
	inputs_tile = tf.tile(inputs_sum, [1, num_agents ,1])  
	inputs_added = (   inputs_tile   - inputs_reshape   )  /  float(num_agents-1)

	inputs_reshape2 = tf.reshape(inputs_added, tf.shape(inputs) )

	inputs_concat = tf.concat([inputs,inputs_reshape2] ,1 )

	out = tu.fc_layer(layer_name,inputs_concat,dim,activation)
	return out


def build(params,net_name,agent_type,device="/gpu:0"):
	activations = params['activations']
	print ('Building ' + net_name )
	with tf.device(device):
		with tf.variable_scope(net_name) as vs:	
			#input
			x = tf.placeholder('float',[None,params['perception_dim']],name='x') #batch*max_num_agents,perception_dim
			action = tf.placeholder("float", [None, params['num_actions']],name='actions')
			returns = tf.placeholder("float",[None,1],name='returns')
			mask = tf.placeholder("float",[None,1],name='mask') #dead agents are masked, batch*max_num_agents
			batch_size = tf.placeholder("float",name='batch_size')

			#fc layer
			if agent_type == 'ours' :
				#common feature
				h0 = tu.fc_layer('h0',x,params['dim_fc_ours'][0],'elu')
				h1 = tu.fc_layer('h1',h0,params['dim_fc_ours'][1],'elu')
				#receiver and transmitter
				rec = tu.fc_layer('receiver',h1,params['dim_comm_ours'][0],'linear',bias=False) #receiver, TODO : linear or tanh
				tran = tu.fc_layer('transmitter',h1,params['dim_comm_ours'][0],'linear',bias=False) #transmitter
				#get attention
				rec_reshape = tf.reshape(rec,[-1,params['num_agents'],params['dim_comm_ours'][0]])
				tran_reshape = tf.reshape(tran,[-1,params['num_agents'],params['dim_comm_ours'][0]])
				tran_reshape_trans = tf.transpose(tran_reshape,[0,2,1])
				rec_tran_mul = tf.matmul(rec_reshape,tran_reshape_trans)
		
		

				mask_reshape1 = tf.reshape(mask,[-1,params['num_agents'],1])
				mask_reshape2 = tf.reshape(mask,[-1,1,params['num_agents']])
				mask_mul = tf.matmul(mask_reshape1,mask_reshape2)

				rtm = rec_tran_mul*mask_mul
				rtmmax = tf.reduce_max(rtm,axis=2,keep_dims=True)
				rtmsub = rtm-rtmmax

				rt_exp = tf.exp(rtmsub)

				rt_exp_masked = rt_exp*mask_mul
				rt_exp_sum = tf.maximum(1e-10,   tf.reduce_sum(rt_exp_masked,axis=2,keep_dims=True)   )

				attention = tf.div(rt_exp_masked,rt_exp_sum)
				#get comm feature
				attention_reshape = tf.reshape(attention,[-1,params['num_agents'],params['num_agents'],1])
				h1_reshape = tf.reshape(h1,[-1,params['num_agents'],1,params['dim_fc_ours'][0]])
				comm = tf.matmul(attention_reshape,h1_reshape)
				comm = tf.reduce_sum(comm,axis=2)
				comm_reshape = tf.reshape(comm,[-1,params['dim_fc_ours'][0]])
				#final feature
				h_last = tf.concat([h1,comm_reshape],1)
				#h_last = tu.fc_layer('h2',f_last,params['dim_fc_ours'][1],'elu')
			
			
			
			elif agent_type == 'commnn' :
				x_masked = x*mask
				h1 = commnn_layer('h1',x_masked,params['dim_fc_commnn'][0],'elu',params['num_agents'])   
				h1_masked = h1*mask	
				h_last = commnn_layer('h2',h1_masked,params['dim_fc_commnn'][1],'elu',params['num_agents'])   	

			elif agent_type == 'dense' :
				x_masked = x*mask
				x_masked_dense = tf.reshape(x_masked,[-1,params['num_agents']*params['perception_dim']])
				h1 = tu.fc_layer('h1',x_masked_dense,params['num_agents']*params['dim_fc_dense'][0],'elu')				
				h_last =  tu.fc_layer('h2',h1,params['num_agents']*params['dim_fc_dense'][1],'elu') 
				h_last = tf.reshape(h_last,[-1,params['dim_fc_dense'][1]])

			elif agent_type == 'nocomm' :
				x_masked = x*mask
				h1 = tu.fc_layer('h1',x_masked,params['dim_fc_nocomm'][0],'elu')
				h1_masked = h1*mask	
				h_last =  tu.fc_layer('h2',h1_masked,params['dim_fc_nocomm'][1],'elu') 
	
			else : raise ValueError


			#State Value
			with tf.variable_scope('v') as vs_v:
				value = tu.fc_layer('value',h_last,hiddens=1,activation='linear') * mask
		
			#Softmax_Policy
			with tf.variable_scope('p') as vs_p:
				policy = tu.fc_layer('policy',h_last,hiddens=params['num_actions'],activation='softmax') * mask

			#Loss
			log_policy = tf.log(tf.clip_by_value(policy, 1e-4, 1.0)) 
			advantage = (returns - value) 
			loss_ac_p = tf.reduce_sum(action*log_policy,1,keep_dims=True)*tf.stop_gradient(advantage)
			loss_ac_v = 0.25*tf.square(advantage)

			entropy = -tf.reduce_sum(log_policy*policy,1,keep_dims=True)
			loss_ac_p += params['entropy_reg_coeff']*entropy		

			loss_ac_p = -tf.reduce_mean(loss_ac_p*mask) #Policy gradient uses gradient ascent (not descent!)
			loss_ac_v = tf.reduce_mean(loss_ac_v*mask)

			loss_total = loss_ac_p+loss_ac_v
	

		#grads
		vars_all = tu.get_all_var_from_net(net_name)	
		lr = tf.placeholder('float')
		#optimizer = tf.train.RMSPropOptimizer(lr,params['rms_decay'],params['rms_momentum'],params['rms_eps'],use_locking=False)
		optimizer = tf.train.AdamOptimizer(lr,use_locking=False)
		gvs = tf.gradients(loss_total,vars_all)
		if params['clip_grad']:		
			gvs,grad_global_norm = tf.clip_by_global_norm(gvs, params['grad_clip_norm'])
		else : grad_global_norm = tf.constant(0)

		gvs = list(zip(gvs, vars_all))
		train = optimizer.apply_gradients(gvs)

		frame_ph = tf.placeholder(tf.int32)
	
	with tf.device("/cpu:0"): 
		global_frame = tf.Variable(0, name='global_step', trainable=False)
		gf_op = tf.assign_add(global_frame,tf.reduce_sum(frame_ph))	


	output = {'x':x, 
		'action':action,
		'returns':returns,
		'policy':policy,
		'value':value,
		'loss_total':loss_total,
		'vars_all':vars_all,
		'grad' : gvs,
		'entropy':tf.reduce_mean(entropy),
		'loss_p' : loss_ac_p,
		'loss_v' : loss_ac_v,
		'train':train,
		'global_frame':global_frame,
		'global_frame_ph':frame_ph,
		'global_frame_op':gf_op,
		'lr_ph':lr,
		'mask_ph':mask,
		'batch_size':batch_size,
		'grad_norm':grad_global_norm,
		'agent_type':agent_type,
		}

	if agent_type == 'ours' : output['attention']=attention

	return output
		
