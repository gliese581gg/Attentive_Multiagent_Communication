'''
Worker module for Asynchronous Methods for Deep Reinforcement Learning 
Jinyoung Choi
'''
import numpy as np
import tensorflow as tf
import time
import TF_utils_cjy as tu
import sys
import argparse
from preprocessing import preprocess

import env_combat

class worker:
	def __init__(self,worker_idx,params,net1,net2,session,queue1,queue2,worker_summary_dict,Control,target_net = None):
		self.dead = False
		self.params = params
		self.idx = worker_idx
		#environment
		if self.idx == 0 and self.params['show_0th_thread'] : 	show = True
		else : show = False
		if self.idx == 0 : self.log_csv = []
		self.env=env_combat.env_combat(self.params,show)
		self.per = self.env.reset()

		#networks
		self.net1 = net1
		self.net2 = net2
		self.sess = session
		self.global_frame = net1['global_frame']
		self.frame_ph = net1['global_frame_ph']
		self.gf_op = net1['global_frame_op']
		self.lr_ph = net1['lr_ph']
		self.summary_op = worker_summary_dict['op']
		self.summary_writer1 = worker_summary_dict['writer1']
		if net2 is not None : self.summary_writer2 = worker_summary_dict['writer2']
		self.queue1 = queue1
		self.queue2 = queue2
		self.control = Control

		self.target1 = net1 #In A3C, the target network is local network (for code sharing with DQN)
		self.target2 = net2 #In A3C, the target network is local network (for code sharing with DQN)


	def run_worker(self,thread_idx):
		self.per = self.env.reset()
		epi_end = 0
		epi_reward1 = 0.
		epi_reward2 = 0.
		num_epi = 0
		epi_win1 = 0
		epi_win2 = 0
		step = 0
		acc_step = 0
		gf = self.sess.run(self.net1['global_frame'])
		if self.net2 is not None : gf2 = self.sess.run(self.net2['global_frame'])
		start_time = time.time()
		acc_reward1 = 0. 
		acc_reward2 = 0. 

		self.per = np.zeros((2*self.params['num_agents'],self.params['perception_dim']))

		while gf < self.params['max_T']:

			buffer_states1 = np.zeros((self.params['max_step'],self.params['num_agents'],self.params['perception_dim']))	
			buffer_actions1 = np.zeros((self.params['max_step'],self.params['num_agents'],self.params['num_actions']))
			buffer_rewards1 = np.zeros((self.params['max_step'],self.params['num_agents'],1))
			buffer_masks1 = np.zeros((self.params['max_step'],self.params['num_agents'],1))

			if self.net2 is not None :
				buffer_states2 = np.zeros((self.params['max_step'],self.params['num_agents'],self.params['perception_dim']))	
				buffer_actions2 = np.zeros((self.params['max_step'],self.params['num_agents'],self.params['num_actions']))
				buffer_rewards2 = np.zeros((self.params['max_step'],self.params['num_agents'],1))
				buffer_masks2 = np.zeros((self.params['max_step'],self.params['num_agents'],1))

			while step < self.params['max_step'] and epi_end == 0:

				if self.control[0] ==1 : continue

				self.per = self.env.percieve()
				mask = self.env.get_mask()
				att1 =  None
				att2 = None
				fd = {}
				fd[self.net1['x']]=self.per[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ]
				fd[self.net1['mask_ph']]=mask[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ]
				fd[self.net1['global_frame_ph']]=1
				if self.net2 is not None:
					fd[self.net2['x']]=self.per[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ]
					fd[self.net2['mask_ph']]=mask[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ]
					fd[self.net2['global_frame_ph']]=1

					if self.net1['agent_type'] == 'ours':
						pol1,val1,_inc_frame,gf,att1,pol2,val2,_inc_frame,gf2 = self.sess.run([self.net1['policy'],self.net1['value'],self.net1['global_frame_op'],self.net1['global_frame'],self.net1['attention'],self.net2['policy'],self.net2['value'],self.net2['global_frame_op'],self.net2['global_frame']],feed_dict = fd)
					else :
						pol1,val1,_inc_frame,gf,pol2,val2,_inc_frame,gf2 = self.sess.run([self.net1['policy'],self.net1['value'],self.net1['global_frame_op'],self.net1['global_frame'],self.net2['policy'],self.net2['value'],self.net2['global_frame_op'],self.net2['global_frame']],feed_dict = fd)
				else : 
					if self.net1['agent_type'] == 'ours':
						pol1,val1,_inc_frame,gf,att1 = self.sess.run([self.net1['policy'],self.net1['value'],self.net1['global_frame_op'],self.net1['global_frame'],self.net1['attention']],feed_dict = fd)
					else :
						pol1,val1,_inc_frame,gf = self.sess.run([self.net1['policy'],self.net1['value'],self.net1['global_frame_op'],self.net1['global_frame']],feed_dict = fd)

	
				if acc_step % 1000 == 0 and self.idx==0 : 
					print ('0th thread global_step/pol/val')
					print (gf)
					print (pol1)
					print (val1)
					if self.net2 is not None : 
						print ('')
						print (gf2)
						print (pol2)
						print (val2)
				action = np.zeros(2*self.params['num_agents'])
				action[:] = self.params['num_actions']-1

				for ag in range(self.params['num_agents']):
					seed = np.random.random()
					acc_prob = 0.
					for i in range(self.params['num_actions']):
						acc_prob += pol1[ag,i]
						if seed < acc_prob : action[ag+self.env.offset1] = i ; break
				if self.net2 is not None:
					for ag in range(self.params['num_agents']):
						seed = np.random.random()
						acc_prob = 0.
						for i in range(self.params['num_actions']):
							acc_prob += pol2[ag,i]
							if seed < acc_prob : action[ag+self.env.offset2] = i ; break


				step_result = [[0.,0.],[0.,0.]]
				epi_end = 0.


				#TODO visualization
				#if self.idx == 0 and self.params['show_0th_thread'] : 
				#	cv2.imshow('Worker'+str(self.idx)+'_screen',cv2.cvtColor(self.img, cv2.COLOR_RGB2BGR))
			
				per_next,step_result,epi_end,mask_next=self.env.step(action,att1,att2)

				action_onehot = np.zeros((2*self.params['num_agents'],self.params['num_actions']))
				action_onehot[np.arange(2*self.params['num_agents']),action.astype('int')]=1.0

				buffer_states1[step] = self.per[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ].copy()
				buffer_actions1[step] = action_onehot[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ].copy()
				buffer_rewards1[step,:,:] = step_result[0][self.env.agent1_team-1]
				buffer_masks1[step] = mask[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ].copy()

				if self.net2 is not None :
					buffer_states2[step] = self.per[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ].copy()
					buffer_actions2[step] = action_onehot[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ].copy()
					buffer_rewards2[step,:,:] = step_result[0][self.env.agent2_team-1]
					buffer_masks2[step] = mask[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ].copy()


				step+=1 ; acc_step+=1 ; epi_reward1 += step_result[0][self.env.agent1_team-1] ; epi_reward2 += step_result[0][self.env.agent2_team-1]
				w1 = step_result[1][self.env.agent1_team-1]
				w2 = step_result[1][self.env.agent2_team-1]

			fd = {}
			fd[self.target1['x']] = per_next[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ].copy()
			fd[self.target1['mask_ph']] = mask_next[   self.env.offset1 : self.env.offset1+self.params['num_agents']   ].copy()
			if self.net2 is not None:
				fd[self.target2['x']] = per_next[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ].copy()
				fd[self.target2['mask_ph']] = mask_next[   self.env.offset2 : self.env.offset2+self.params['num_agents']   ].copy()
				Vnext1,Vnext2 = self.sess.run([self.target1['value'],self.target2['value']],fd)
			else : Vnext1 = self.sess.run(self.target1['value'],fd)

			R = (1-epi_end)*Vnext1
			buffer_returns1 = buffer_rewards1.copy()

			for i in range(step-1,-1,-1):
				buffer_returns1[i] += self.params['discount']*R
				R = buffer_returns1[i]

			if self.net2 is not None:

				R = (1-epi_end)*Vnext2
				buffer_returns2 = buffer_rewards2.copy()

				for i in range(step-1,-1,-1):
					buffer_returns2[i] += self.params['discount']*R
					R = buffer_returns2[i]

				if len(self.queue2) < self.params['queue_max'] :
					self.queue2.append([buffer_states2.reshape((-1,self.params['perception_dim'])),
								buffer_actions2.reshape((-1,self.params['num_actions'])),
								buffer_returns2.reshape((-1,1)),
								buffer_masks2.reshape((-1,1)),
								step])

			if len(self.queue1) < self.params['queue_max'] :
				self.queue1.append([buffer_states1.reshape((-1,self.params['perception_dim'])),
							buffer_actions1.reshape((-1,self.params['num_actions'])),
							buffer_returns1.reshape((-1,1)),
							buffer_masks1.reshape((-1,1)),
							step])





			if epi_end == 1:
				if w1 == 1 : epi_win1 +=1
				if w2 == 1 : epi_win2 +=1
				self.per = self.env.reset()
				summary = tf.Summary()
				summary.value.add(tag='episode_reward', simple_value=float(epi_reward1))
				self.summary_writer1.add_summary(summary, gf)	
				self.summary_writer1.flush()

				if self.net2 is not None :
					summary2 = tf.Summary()
					summary2.value.add(tag='episode_reward', simple_value=float(epi_reward2))
					self.summary_writer2.add_summary(summary2, gf2)	
					self.summary_writer2.flush()

				acc_reward1 += epi_reward1
				acc_reward2 += epi_reward2
				epi_end = 0
				epi_reward1 = 0
				epi_reward2 = 0
				num_epi += 1


			if num_epi >= self.params['score_display_interval'] and self.idx == 0:
				temp = []
				gf_percent = 100.0*float(gf)/float(self.params['max_T'])
				frame_per_sec = float(gf)/float(time.time()-start_time)
				print( 'Total running time : ' + str(time.time()-start_time) + '('+str(frame_per_sec) +' frames/sec) '   )
				print( '    # of frames : ' + str(gf) +' / ' + str(self.params['max_T'])+', '+str(gf_percent) +'%)'   )
				print( '    0th thread average_reward1 : ' + str(acc_reward1/max(1,num_epi)) + ' (' + str(num_epi) + ' episodes)'   )
				print( '    win_rate1 : ' + str(int(epi_win1)) + '/' + str(int(num_epi)) + ' (' + str(   float(epi_win1)/float(num_epi)   ) + ')'   )

				summary = tf.Summary()
				summary.value.add(tag='win_rate', simple_value=float(epi_win1)/float(num_epi)   )
				self.summary_writer1.add_summary(summary, gf)	
				self.summary_writer1.flush()
				temp.append(   float(epi_win1)/float(num_epi)   )
				if self.net2 is not None :
					print( '    0th thread average_reward2 : ' + str(acc_reward2/max(1,num_epi)) + ' (' + str(num_epi) + ' episodes)'   )
					print( '    win_rate2 : ' + str(int(epi_win2)) + '/' + str(int(num_epi)) + ' (' + str(   float(epi_win2)/float(num_epi)   ) + ')'   )
					summary2 = tf.Summary()
					summary2.value.add(tag='win_rate', simple_value=float(epi_win2)/float(num_epi)   )
					self.summary_writer2.add_summary(summary2, gf2)	
					self.summary_writer2.flush()
					temp.append(   float(epi_win2)/float(num_epi)   )

				self.log_csv.append(temp)
				np.savetxt(self.params['log_path']+"winrate_log.csv", np.array(self.log_csv), delimiter=",")
				acc_reward1 = 0.
				epi_win1 = 0
				acc_reward2 = 0.
				epi_win2 = 0
				num_epi = 0

			step=0

		

