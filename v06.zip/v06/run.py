'''
Asynchronous Methods for Deep Reinforcement Learning 
Jinyoung Choi
'''
import numpy as np
import tensorflow as tf
import time
import TF_utils_cjy as tu
import sys
import argparse
import env_combat
if sys.version_info.major == 2:import thread
elif sys.version_info.major == 3:import _thread as thread
else : raise ValueError
import worker
import parameters
from preprocessing import preprocess
import os

params = parameters.load_params()

ap = argparse.ArgumentParser()
ap.add_argument("-name", "--exp_name", required = False, help = "experiment name")
ap.add_argument("-a1", "--agent1", required = False, help = "agent 1")
ap.add_argument("-a2", "--agent2", required = False, help = "agent 2")
ap.add_argument("-show", "--show_0th_thread", required = False, help = "show evaluation screen? (True or False)")
ap.add_argument("-eval_mode", "--eval_mode", required = False, help = "Evaluation only (True or False)")
ap.add_argument("-ckpt1", "--ckpt_agent1", required = False, help = "checkpoint name for agent1(without path)")
ap.add_argument("-ckpt2", "--ckpt_agent2", required = False, help = "checkpoint name for agent2 (without path)")
ap.add_argument("-device", "--device", required = False, help = "checkpoint name for agent2 (without path)")

args = vars(ap.parse_args())
print( args)
for i in args.keys():
	if i in params.keys() and args[i] is not None:
		if args[i] == 'True' : aar = True
		elif args[i] == 'False' : aar = False
		else : aar = args[i]
		params[i] = aar

params['log_path'] = params['log_path']+params['exp_name']+'/'
params['ckpt_path'] = params['ckpt_path']+params['exp_name']+'/'

if params['ckpt_agent1'] is None and params['ckpt_agent2'] is None : #new experiment
	if os.path.isdir(params['log_path']):
		print('rm -rf '+ params['log_path'] + '*')
		os.system('rm -rf '+ params['log_path'] + '*')
	else : os.mkdir(params['log_path'])
	if os.path.isdir(params['ckpt_path']):
		print('rm -rf '+ params['ckpt_path'] + '*')
		os.system('rm -rf '+ params['ckpt_path'] + '*')
	else : os.mkdir(params['ckpt_path'])


if params['env_debug'] : params['eval_mode']=True
if params['eval_mode'] : params['num_workers'] = 1
#if params['LSTM'] : params['history'] = 1
params['num_actions'] = params['num_agents']+4

#environment
env = env_combat.env_combat(params)
per = env.reset()
params['num_actions'] = env.action_space.n
params['perception_dim'] = env.perception_dim

'''
if params['show_eval'] : 
	cv2.startWindowThread()
	cv2.namedWindow('Evaluation')
'''
#build_networks

import Net_A3C

net1 = Net_A3C.build(params,params['agent1'],params['agent1'],params['device'])
tu.display_num_params(params['agent1'])
saver1 = tf.train.Saver(net1['vars_all']) #TODO save only the master net
net2 = None
if params['agent2'] != 'bot' :
	net2 = Net_A3C.build(params,params['agent2'],params['agent2'],params['device'])
	tu.display_num_params(params['agent2'])
	saver2 = tf.train.Saver(net2['vars_all']) #TODO save only the master net
#raise ValueError
workers = []

gpu_config = tf.ConfigProto()
gpu_config.gpu_options.allow_growth = True


sess = tf.Session(config=gpu_config)
sess.run(tf.global_variables_initializer())

summary_op = tf.summary.merge_all()
log1 = params['log_path']+params['agent1']
summary_writer1 = tf.summary.FileWriter(log1, sess.graph_def)
worker_summary_dict = {'op':summary_op,'writer1':summary_writer1}
if params['agent2'] != 'bot' : 
	log2 = params['log_path']+params['agent2']
	summary_writer2 = tf.summary.FileWriter(log2, sess.graph_def)
	worker_summary_dict['writer2']= summary_writer2


if params['ckpt_agent1'] is not None : 
	print( 'Load ckpt for agent1 ',params['ckpt_agent1'])
	saver1.restore(sess,params['ckpt_agent1'])
if params['ckpt_agent2'] is not None : 
	print( 'Load ckpt for agent2 ',params['ckpt_agent2'])
	saver2.restore(sess,params['ckpt_agent2'])

#Create workers and Experience Queue
Exp_Queue1 = []
Exp_Queue2 = []
Control = [0] #shared across all threads. 0 means 'do training', 1 means 'pause'

for i in range(params['num_workers']):
		print( 'Initializing Thread ' + str(i))
		# worker_idx,params,worker_net,copy_master_to_worker,copy_master_to_target,train_p,train_v,session,master,target,global_step
		workers.append(worker.worker(i,params,net1,net2,sess,Exp_Queue1,Exp_Queue2,worker_summary_dict,Control))
		thread.start_new_thread(workers[i].run_worker,(i,))

#Start training
gf = sess.run(net1['global_frame'])
last_eval_frame = gf
last_save = gf
last_target_copy = gf

print( 'Start learning. Hyper paramters are:')
print( params)

def do_training():
	global sess
	global net1
	global Exp_Queue1
	global net2
	global Exp_Queue2
	global params
	global gf
	if Control[0] == 1 or params['eval_mode'] : return None

	if len(Exp_Queue1) <= params['queue_min'] : return None
	if net2 is not None and len(Exp_Queue2) <= params['queue_min'] : return None

	queue_zip = list(  zip(*Exp_Queue1)  )
	states = list(queue_zip[0])
	actions = list(queue_zip[1])
	returns = list(queue_zip[2])
	mask = list(queue_zip[3])
	#no need for step (we don't use LSTM)

	del Exp_Queue1[:]

	lr = params['lr']

	states = np.concatenate(states,0)
	actions = np.concatenate(actions,0)
	returns = np.concatenate(returns,0)
	mask = np.concatenate(mask,0)

	tfd = {net1['x'] : states,
		net1['action'] : actions,
		net1['returns'] : returns,
		net1['lr_ph'] : lr,
		net1['mask_ph'] : mask
		}

	if net2 is not None :
		queue_zip2 = list( zip(*Exp_Queue2)  )
		states2 = list(queue_zip2[0])
		actions2 = list(queue_zip2[1])
		returns2 = list(queue_zip2[2])
		mask2 = list(queue_zip2[3])
		#no need for step (we don't use LSTM)

		del Exp_Queue2[:]

		lr = params['lr']

		states2 = np.concatenate(states2,0)
		actions2 = np.concatenate(actions2,0)
		returns2 = np.concatenate(returns2,0)
		mask2 = np.concatenate(mask2,0)

		tfd[ net2['x'] ] = states2
		tfd[ net2['action'] ] = actions2
		tfd[ net2['returns'] ] = returns2
		tfd[ net2['lr_ph'] ] = lr
		tfd[ net2['mask_ph'] ] = mask2

		_,e,gf,loss_v,loss_p,entropy,grad,_2,e2,gf2,loss_v2,loss_p2,entropy2,grad2 = sess.run([net1['train'],net1['loss_total'],net1['global_frame'],net1['loss_v'],net1['loss_p'],net1['entropy'],net1['grad_norm'],net2['train'],net2['loss_total'],net2['global_frame'],net2['loss_v'],net2['loss_p'],net2['entropy'],net2['grad_norm']],tfd)

		summary = tf.Summary()
		summary.value.add(tag='loss_v', simple_value=float(loss_v))
		summary.value.add(tag='loss_p', simple_value=float(loss_p))
		summary.value.add(tag='entropy', simple_value=float(entropy))
		summary.value.add(tag='lr', simple_value=float(lr))
		summary.value.add(tag='minibatch_size', simple_value=float(mask.shape[0]))						
		summary.value.add(tag='grad_norm', simple_value=float(grad))

		summary2 = tf.Summary()
		summary2.value.add(tag='loss_v', simple_value=float(loss_v2))
		summary2.value.add(tag='loss_p', simple_value=float(loss_p2))
		summary2.value.add(tag='entropy', simple_value=float(entropy2))
		summary2.value.add(tag='lr', simple_value=float(lr))
		summary2.value.add(tag='minibatch_size', simple_value=float(mask2.shape[0]))						
		summary2.value.add(tag='grad_norm', simple_value=float(grad2))

		summary_writer1.add_summary(summary, gf)	
		summary_writer1.flush()

		summary_writer2.add_summary(summary2, gf2)	
		summary_writer2.flush()

		if e > 50000 or e2 > 50000 : raise ValueError

	else : 
		_,e,gf,loss_v,loss_p,entropy,grad = sess.run([net1['train'],net1['loss_total'],net1['global_frame'],net1['loss_v'],net1['loss_p'],net1['entropy'],net1['grad_norm']],tfd)

		summary = tf.Summary()
		summary.value.add(tag='loss_v', simple_value=float(loss_v))
		summary.value.add(tag='loss_p', simple_value=float(loss_p))
		summary.value.add(tag='entropy', simple_value=float(entropy))
		summary.value.add(tag='lr', simple_value=float(lr))
		summary.value.add(tag='minibatch_size', simple_value=float(mask.shape[0]))						
		summary.value.add(tag='grad_norm', simple_value=float(grad))

		summary_writer1.add_summary(summary, gf)	
		summary_writer1.flush()

		if e > 50000 : raise ValueError





while gf < params['max_T'] :

	for ii in range(len(workers)):
		if workers[ii].dead : raise ValueError

	gf = sess.run(net1['global_frame'])

	do_training()

	if gf > last_save + params['save_interval'] and not params['eval_mode'] : 
		saver1.save(sess, params['ckpt_path']+'ckpt_'+params['agent1']+'_'+str(gf))
		if net2 is not None : saver2.save(sess, params['ckpt_path']+'ckpt_'+params['agent2']+'_'+str(gf))
		print( 'Model saved as ckpt/ckpt'+str(gf))
		last_save = gf

	#time.sleep(0.1)





